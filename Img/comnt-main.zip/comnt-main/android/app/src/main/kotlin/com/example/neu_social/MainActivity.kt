package com.example.neu_social

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
