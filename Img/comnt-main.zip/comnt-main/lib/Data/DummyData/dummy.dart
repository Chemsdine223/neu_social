import 'package:neu_social/Data/Models/community.dart';
import 'package:neu_social/Data/Models/event.dart';
import 'package:neu_social/Data/Models/user.dart';
import 'package:neu_social/Data/Models/post.dart';

// Define more dummy users
final List<UserModel> users = [
  UserModel(
    firstname: "jaffar",
    lastname: 'hmd',
    email: 'jaffar@example.com',
    dob: DateTime.parse("1995-06-12"),
  ),
  UserModel(
    firstname: "Dr.",
    lastname: 'diyah',
    email: 'diyah@example.com',
    dob: DateTime.parse("1997-03-11"),
  ),
  UserModel(
    firstname: "sejade",
    lastname: 'prof',
    email: 'sejade@example.com',
    dob: DateTime.parse("1998-01-15"),
  ),
  UserModel(
    firstname: "amar",
    lastname: 'amar',
    email: 'amar@example.com',
    dob: DateTime.parse("1992-07-24"),
  ),
  UserModel(
    firstname: "hamadi",
    lastname: 'abass',
    email: 'bob@example.com',
    dob: DateTime.parse("1990-11-05"),
  ),
  UserModel(
    firstname: "kemal",
    lastname: 'kemal',
    email: 'kemal@example.com',
    dob: DateTime.parse("1985-04-20"),
  ),
  UserModel(
    firstname: "saadbouh",
    lastname: 'saadbouh',
    email: 'saadbouh@example.com',
    dob: DateTime.parse("1995-06-12"),
  ),
  UserModel(
    firstname: "jaffar",
    lastname: 'hmd',
    email: 'amy.brown@example.com',
    dob: DateTime.parse("1997-03-11"),
  ),
];

// Define dummy posts
final List<Post> posts = [
  Post(user: users[0], post: 'Ceci est une publication de jaffar.'),
  Post(user: users[1], post: 'hamadi partage ses pensées.'),
  Post(user: users[2], post: 'diyah écrit sur sa journée.'),
  Post(user: users[3], post: 'amar discute de son dernier projet.'),
  Post(user: users[4], post: 'Bob  publie un mème amusant.'),
  Post(user: users[5], post: 'saadbouh partage une belle photo.'),
  Post(user: users[6], post: 'kemal parle de sa nouvelle startup.'),
  Post(user: users[7], post: 'jaffar partage une recette pour un repas sain.'),
];


List<EventModel> dummyEvents = [
  EventModel(
    time: '00:22',
    name: 'Tech Expo 2024',
    date: DateTime(2024, 6, 15),
    description:
        'Une grande exposition présentant les dernières avancées en technologie et innovation. Conférences, ateliers et sessions de réseautage avec des leaders de l\'industrie.',
    creator: users[2],
    location: 'TVZ',
  ),
  EventModel(
    time: '12:25',
    name: 'Atelier axé sur le mode de vie sain',
    date: DateTime(2024, 7, 10),
    description:
        'Un atelier axé sur le mode de vie sain, comprenant des séances de yoga, des plans de régime',
    creator: users[3],
    location: 'Lekssar',
  ),
  EventModel(
    time: '20:30',
    name: 'Festival d\'été de musique',
    date: DateTime(2024, 8, 5),
    description:
        'Rejoignez-nous pour un week-end de musique live, de food trucks et de divertissement.',
    creator: users[6],
    location: 'Cite palge',
  ),
  EventModel(
    time: '21:00',
    name: 'Cours de cuisine gastronomique',
    date: DateTime(2024, 6, 20),
    description:
        'Apprenez à cuisiner des plats gastronomiques avec des chefs professionnels.',
    creator: users[5],
    location: 'École d\'arts culinaires',
  ),
  EventModel(
    time: '22;00',
    name: 'Voyage de randonnée en pleine nature',
    date: DateTime(2024, 7, 25),
    description:
        'Un voyage de randonnée guidée à travers des sentiers pittoresques.',
    creator: users[0],
    location: 'ATAR',
  ),
  EventModel(
    time: '23:00',
    name: 'Séminaire sur les stratégies d\'investissement',
    date: DateTime(2024, 9, 15),
    description:
        'Un séminaire approfondi sur les stratégies d\'investissement modernes et la planification ',
    creator: users[2],
    location: 'Hotel Nouakchott',
  ),
  EventModel(
    time: '08:45',
    name: 'Retraite axée sur le bien-être mental et physique',
    date: DateTime(2024, 10, 5),
    description:
        'Un week-end de retraite axé sur le bien-être mental et physique.',
    creator: users[3],
    location: 'Hotel Emira',
  ),
  EventModel(
    time: '12:00',
    name: 'Nuit du Jazz',
    date: DateTime(2024, 11, 10),
    description:
        'Soirée de performances de jazz par des artistes locaux. Profitez de la bonne musique et de la fine cuisine.',
    creator: users[6],
    location: 'Palacio',
  ),
  EventModel(
    time: '15:00',
    name: 'Festival International de la Gastronomie',
    date: DateTime(2024, 9, 30),
    description:
        'Un festival célébrant les traditions culinaires du monde entier. Dégustez des plats de différentes cultures et assistez à des démonstrations culinaires.',
    creator: users[5],
    location: 'Central Plaza',
  ),
  EventModel(
    time: '18:00',
    name: 'Expédition Photographique',
    date: DateTime(2024, 12, 12),
    description:
        'Une expédition photographique menée par des photographes professionnels. Explorez des lieux pittoresques et améliorez vos compétences en photographie.',
    creator: users[0],
    location: 'JETSET',
  ),
];


// Define dummy communities
List<Community> dummyCommunities = [
  Community(
    events: [dummyEvents[0], dummyEvents[1]],
    creator: users[2],
    type: 'payé',
    id: 1,
    image: 'Img/investment.png',
    name: 'Passionnés de technologie',
    interests: ['Technologie', 'Science'],
    description:
        'Une communauté pour les personnes passionnées par les dernières avancées en technologie, gadgets et développement de logiciels.',
    users: [users[0], users[1], users[2], users[3]],
    posts: [posts[0], posts[3], posts[6]],
  ),
  Community(
    events: [dummyEvents[2], dummyEvents[3]],
    creator: users[3],
    type: 'basé sur les événements',
    id: 2,
    image: 'Img/better-health.png',
    name: 'Santé et Bien-être',
    interests: ['Santé', 'Style de vie'],
    description:
        'Une communauté axée sur la santé, le bien-être et la forme physique. Partagez des conseils, des articles et des histoires personnelles.',
    users: [users[4], users[5], users[6], users[7]],
    posts: [posts[1], posts[2], posts[7]],
  ),
  Community(
    events: [dummyEvents[6], dummyEvents[7]],
    creator: users[6],
    type: 'basé sur invitation',
    id: 3,
    image: 'Img/love-song.png',
    name: 'Amoureux de la musique',
    interests: ['Musique'],
    description:
        'Rejoignez d\'autres passionnés de musique pour discuter de vos groupes préférés, partager des playlists et parler des dernières sorties.',
    users: [users[0], users[1], users[5]],
    posts: [posts[1], posts[5]],
  ),
  Community(
    events: [dummyEvents[9], dummyEvents[4]],
    creator: users[5],
    id: 4,
    type: 'public',
    image: 'Img/catering.png',
    name: 'Amateurs de gastronomie',
    interests: ['Nourriture', 'Cuisine'],
    description:
        'Un lieu pour les amateurs de gastronomie pour partager des recettes, des astuces de cuisine et des avis sur les restaurants.',
    users: [users[2], users[3], users[7]],
    posts: [posts[3], posts[7]],
  ),
  Community(
    events: [dummyEvents[6], dummyEvents[9]],
    creator: users[0],
    type: 'privé',
    id: 5,
    image: 'Img/business-trip.png',
    name: 'Passionnés de voyage',
    interests: ['Voyage', 'Aventure'],
    description:
        'Partagez vos expériences de voyage, photos et astuces. Trouvez des compagnons de voyage et planifiez votre prochaine aventure.',
    users: [users[4], users[5], users[6]],
    posts: [posts[4], posts[6]],
  ),
];

