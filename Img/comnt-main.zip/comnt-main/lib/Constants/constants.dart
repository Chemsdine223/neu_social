List<String> defaultInterests = [
  'Lecture',
  'Voyage',
  'Cuisine',
  'Sports',
  'Musique',
  'Films',
  'Photographie',
  'Technologie',
  'Jeux vidéo',
  'Fitness',
  'Santé',
  'Art',
  'Style de vie',
  'Nourriture',
  'Aventure',
  'Jardinage',
  'Écriture',
  'Mode',
  'Science',
  'Histoire',
  'Artisanat',
  'Randonnée',
  'Danse',
  'Yoga'
];

List<String> months = [
  'Janvier',
  'Février',
  'Mars',
  'Avril',
  'Mai',
  'Juin',
  'Juillet',
  'Août',
  'Septembre',
  'Octobre',
  'Novembre',
  'Décembre'
];

List<String> types = [
  "Privé",
  "Basé sur les événements",
  "Basé sur invitation",
  "Payé",
  "Public",
];
