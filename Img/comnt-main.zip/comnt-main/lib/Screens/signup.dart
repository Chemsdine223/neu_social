import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:neu_social/Logic/SignupCubit/signup_cubit.dart';
import 'package:neu_social/Screens/interests_screen.dart';
import 'package:neu_social/Utils/helpers.dart';
import 'package:neu_social/Utils/size_config.dart';
import 'package:neu_social/Widgets/Buttons/custom_button.dart';
import 'package:neu_social/Widgets/Inputs/custom_input.dart';

class Signup extends StatefulWidget {
  const Signup({super.key});

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  final formKey = GlobalKey<FormState>();
  String? birthDateInString;
  // DateTime? birthDate;
  DateTime? dob;

  final firstnameController = TextEditingController();
  final lastnameController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  void dispose() {
    firstnameController.dispose();
    lastnameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SignupCubit, Authentication>(
      builder: (context, state) {
        return Stack(
          children: [
            Scaffold(
              body: SafeArea(
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: getProportionateScreenWidth(18)),
                  child: Form(
                    key: formKey,
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            height: getProportionateScreenHeight(120),
                          ),
                          SizedBox(
                            width: getProportionateScreenWidth(180),
                            child: Text(
                              'Créer un compte',
                              textAlign: TextAlign.start,
                              style: Theme.of(context)
                                  .textTheme
                                  .displayMedium!
                                  .copyWith(
                                    fontWeight: FontWeight.w500,
                                    color:Color.fromARGB(255, 198, 145, 11)
                                  ),
                            ),
                          ),
                          SizedBox(height: getProportionateScreenHeight(40)),
                          CustomTextField(
                            controller: firstnameController,
                            hintText: 'Prénom',
                            password: false,
                            keyboardType: TextInputType.emailAddress,
                            onChanged: (value) {},
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Le prénom ne peut pas être vide';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: getProportionateScreenHeight(8)),
                          CustomTextField(
                            controller: lastnameController,
                            hintText: 'Nom de famille',
                            password: false,
                            keyboardType: TextInputType.emailAddress,
                            onChanged: (value) {},
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Le nom de famille ne peut pas être vide';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: getProportionateScreenHeight(8)),
                          _dateField(context),
                          SizedBox(height: getProportionateScreenHeight(8)),
                          CustomTextField(
                            controller: emailController,
                            hintText: 'E-mail',
                            password: false,
                            keyboardType: TextInputType.emailAddress,
                            onChanged: (value) {},
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'L\'e-mail ne peut pas être vide';
                              } else if (!RegExp(
                                      r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
                                  .hasMatch(value)) {
                                return 'Veuillez entrer une adresse e-mail valide';
                              }
                              return null;
                            },
                          ),
                          SizedBox(height: getProportionateScreenHeight(8)),
                          CustomTextField(
                            controller: passwordController,
                            hintText: 'Mot de passe',
                            password: true,
                            onChanged: (value) {},
                            validator: (value) {
                              if (value!.isEmpty) {
                                return 'Le mot de passe ne peut pas être vide';
                              }
                              return null;
                            },
                          ),
                          SizedBox(
                            height: getProportionateScreenHeight(18),
                          ),
                          Row(
                            children: [
                              Expanded(
                                child: CustomButton(
                                  onTap: () async {
                                    if (formKey.currentState!.validate()) {
                                      context.read<SignupCubit>().saveUser(
                                          firstnameController.text,
                                          lastnameController.text,
                                          dob!,
                                          emailController.text);
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) =>
                                                const InterestsScreen(),
                                          ));
                                    }
                                  },
                                  color: Colors.green.shade800,
                                  radius: 12,
                                  height: getProportionateScreenHeight(45),
                                  label: Text(
                                    'S\'inscrire',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyLarge!
                                        .copyWith(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            // state == Authentication.loading
            //     ? const CustomOverlay()
            //     : Container(),
          ],
        );
      },
    );
  }

  TextFormField _dateField(BuildContext context) {
    return TextFormField(
      controller:
          TextEditingController(text: dob != null ? formatDateTime(dob!) : ''),
      readOnly: true,
      validator: (value) {
        if (value!.isEmpty) {
          return "La date de naissance ne peut pas être vide";
        }
        return null;
      },
      decoration: InputDecoration(
        hintText: 'jj-MM-aaaa',
        suffixIcon: GestureDetector(
          child: const Icon(Icons.calendar_today),
          onTap: () async {
            final datePick = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(1900),
                lastDate: DateTime.now());
            if (datePick != null) {
              setState(() {
                dob = datePick;
              });
            }
          },
        ),
      ),
    );
  }
}
