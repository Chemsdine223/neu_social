package com.example.places_auto_suggestion

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
